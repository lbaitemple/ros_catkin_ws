#include <iostream>

int main(int, char**)  {
  std::cout << __PRETTY_FUNCTION__ << "\n";
}
