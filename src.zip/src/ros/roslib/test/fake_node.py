#!/usr/bin/env python
# this node only exists to test find_node functionality

print("hello")
